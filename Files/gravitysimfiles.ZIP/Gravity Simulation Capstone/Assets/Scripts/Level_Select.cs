﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class Level_Select : MonoBehaviour
{

    public Text levelText;//Level name

    public int level = 0;// this allows me to change the script for each button withion the unity editor without making several variations.

    Button button;

    Image selected;// when clicked down, use a diffent color

    void Start()
    {
        levelText.text = "level " + (level-1).ToString();
        if (level == 7)
        {
            levelText.text = "SandBox ";
        }

        else if(level==0)
        {
            levelText.text = "Back to Menu ";
        }
        else if (level == 1)
        {
            levelText.text = "Level Select ";
        }
        else if (level == 8)
        {
            levelText.text = "How to play ";
        }
    }

    void OnEnable()
    {
        button = GetComponent<Button>();
        selected = GetComponent<Image>();
    }



    public void OnClick()// click, load new level
    {
        SceneManager.LoadScene(level);
    }
}
