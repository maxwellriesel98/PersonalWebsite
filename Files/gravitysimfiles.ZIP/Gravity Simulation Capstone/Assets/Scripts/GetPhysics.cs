﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class GetPhysics : MonoBehaviour
{
    public Text PhysicsInfo;
    

    Ray Mouse;
    RaycastHit Mousetouch;

    void FixedUpdate()
    {
        Mouse = Camera.main.ScreenPointToRay(Input.mousePosition);//if the mouse is over an object
        
        if(Physics.Raycast(Mouse, out Mousetouch))//print out its info
        {
            PhysicsInfo.text = "Static Friction: " + Mousetouch.collider.material.staticFriction.ToString();
            PhysicsInfo.text = PhysicsInfo.text + "\n" + "Dynamic Friction: " +  Mousetouch.collider.material.dynamicFriction.ToString();
            PhysicsInfo.text = PhysicsInfo.text + "\n"+ "Bounciness: " + Mousetouch.collider.material.bounciness.ToString();
            PhysicsInfo.text = PhysicsInfo.text + "\n" + "Length: " + Mousetouch.transform.localScale.x.ToString();

            if (Mousetouch.rigidbody == null)
            {
                PhysicsInfo.text = PhysicsInfo.text + "\n" + "Mass: Not needed for this equation";
            }
            else
            {
                PhysicsInfo.text = PhysicsInfo.text + "\n" + "Mass: " + Mousetouch.rigidbody.mass.ToString();
            }
            
            

           
            
        }

        else
        {
            PhysicsInfo.text = "";
        }

    }

 
}
