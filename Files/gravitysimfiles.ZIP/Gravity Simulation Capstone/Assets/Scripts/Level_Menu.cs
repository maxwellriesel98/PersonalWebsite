﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Level_Menu : MonoBehaviour
{

    public int Levels = 0;

    private Level_Select[] selection;//all buttons we have


    void OnEnable()
    {
        selection = GetComponentsInChildren<Level_Select>();
    }

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    public void ClickBack()//click the back button
    {
        SceneManager.LoadScene(1);
    }

}
