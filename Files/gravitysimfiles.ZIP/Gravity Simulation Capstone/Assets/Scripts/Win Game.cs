﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class WinGame : MonoBehaviour
{
    int score = 0;
    public Renderer rend;
    public Text Clicks;
    void OnMouseUp()
    {
        score++;
        Clicks.text = "Total Clicks is " + score.ToString();
    }
}
