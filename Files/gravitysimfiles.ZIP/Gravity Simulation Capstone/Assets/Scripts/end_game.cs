﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class end_game : MonoBehaviour
{

    public GameObject Goal;
    int score = 0;
    public Text Clicks;
    public Text Wintext;
    public Image Button;
    public Text ButtonText;
    public Button Exit;

    void Update()
    {
        if (Input.GetMouseButtonDown(0))
        {
            score++;
            Clicks.text = "Total Clicks is " + score.ToString();
        }
       
    }

    void OnCollisionEnter(Collision GoalTouch)
    {
        Destroy(Goal);
        Button.enabled = true;
        ButtonText.enabled = true;
        Button.enabled = true;
        Wintext.enabled = true;
        Wintext.text = "You Won In " + score + " Clicks!";
    }
   
}
