﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine.UI;
using UnityEngine;

public class Launch_ball : MonoBehaviour
{
    public Vector3 gameObjectSreenPoint; //the position of the object in the world 
    public Vector3 mousePreviousLocation;// location of mouse at the beginning of the drag
    public Vector3 mouseCurLocation;//current mouse location
    public Vector3 force;// this is the dorce applie to the ball on drag
    public float velocityAvg;//Avg velocity of the projectile
    public GameObject projectile;//the projectile being launched
    public GameObject launchArrow;//this shows the directon and force the ball will be launched
    public GameObject launchArrowHead;//this shows the directon and force the ball will be launched
    public Text appliedForceY;// this diplays the force you will be applying to the object
    public Text appliedForceX;
    public Text launchAngle;//angle that force is being applied
    public Text velocity;//current volecity of the projectile
    

    public float topSpeed = 10;

    void OnMouseDown()// need to chang this to be click on the object
    {
        
        gameObjectSreenPoint = Camera.main.WorldToScreenPoint(gameObject.transform.position);//This grabs the position of the object in the world and turns it into the position on the screen

        launchArrowHead.GetComponent<MeshRenderer>().enabled = true;// turn on arrow that points at angle of launch

        mousePreviousLocation = new Vector3(Input.mousePosition.x, Input.mousePosition.y, gameObjectSreenPoint.z);//Stores position of mouse to be compare to a later position
    }



    void OnMouseDrag() //shows the force that will be applied to the projectile
    {

        mouseCurLocation = new Vector3(Input.mousePosition.x, Input.mousePosition.y, gameObjectSreenPoint.z);//takes current position of mouse

        force = mouseCurLocation - mousePreviousLocation;//Changes the force to be applied

        //code to make the arrow pont towards the angle the ball will be sent
        Vector3 difference = Camera.main.ScreenToWorldPoint(Input.mousePosition) - launchArrow.GetComponent<Transform>().transform.position;
        difference.Normalize();
        float rotation_z = Mathf.Atan2(difference.y, difference.x) * Mathf.Rad2Deg;
        launchArrow.GetComponent<Transform>().transform.rotation = Quaternion.Euler(0f, 0f, rotation_z);

        //this gives you the info needed to calculate your shots
        appliedForceY.text = "Force Y: " + (force.y * 2).ToString();
        appliedForceX.text = "Force X: " + (force.x * 2).ToString();
        launchAngle.text = "Angle:" + launchArrow.GetComponent<Transform>().rotation.eulerAngles.z.ToString();

    }

    public void OnMouseUp()
    {
        mouseCurLocation = new Vector3(Input.mousePosition.x, Input.mousePosition.y, gameObjectSreenPoint.z);//takes current position of mouse
        force = mouseCurLocation - mousePreviousLocation;//Changes the force to be applied

        launchArrowHead.GetComponent<MeshRenderer>().enabled = false;// turn off arrow that points at angle of launch

        //this will cap the speed
        if (GetComponent<Rigidbody>().velocity.magnitude > topSpeed)
        {
            force = GetComponent<Rigidbody>().velocity.normalized * topSpeed;
        }
        //reset text
        appliedForceY.text = "Force Y: ";
        appliedForceX.text = "Force X: ";
        launchAngle.text = "Angle:";

        //add force to ball
        GetComponent<Rigidbody>().AddForce(force*2f);
    }

    public void FixedUpdate()
    {
        velocityAvg = Mathf.Pow(projectile.GetComponent<Rigidbody>().velocity.y, 2) + Mathf.Pow(projectile.GetComponent<Rigidbody>().velocity.x, 2);
        velocityAvg = Mathf.Sqrt(velocityAvg);
        velocity.text = "Velocity: " + velocityAvg.ToString();
    }

}
